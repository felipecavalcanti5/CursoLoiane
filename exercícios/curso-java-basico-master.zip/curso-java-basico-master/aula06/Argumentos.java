class Argumentos {
	public static void main (String[] args) {
		System.out.println("Você digitou " + args[0]);
	}
}

