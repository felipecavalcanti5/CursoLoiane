package com.loiane.cursojava.aula11;

public class VariaveisInteiras {

	public static void main(String[] args) {
		
		byte idade01 = 20;
		
		short idade02 = 21;
		
		int idade03 = 22;
		
		long idade04 = 23;
		
		System.out.println("Valor variável idade01 = " + idade01);
		System.out.println("Valor variável idade02 = " + idade02);
		System.out.println("Valor variável idade03 = " + idade03);
		System.out.println("Valor variável idade04 = " + idade04);

	}

}
