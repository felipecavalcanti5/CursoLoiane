package com.loiane.cursojava.aula22;

public class DebugEclipse {

	public static void main(String[] args) {
		
		int[] notas = new int[3];
		
		for (int i=0; i<4; i++){
			notas[i] = i;
		}

	}

}
