/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.loiane.cursojava.aula23;

/**
 *
 * @author loiane
 */
public class DebugNetbeans {

    public static void main(String[] args) {

        int[] notas = new int[3];

        for (int i = 0; i < 4; i++) {
            notas[i] = i;
        }

    }
}
