package com.loiane.cursojava.aula31alt;

import com.loiane.cursojava.aula31.Carro;

public class TesteCarroAlt {

	public static void main(String[] args) {
		
		Carro carro = new Carro();
		carro.marca = "Fiat";

	}

}
