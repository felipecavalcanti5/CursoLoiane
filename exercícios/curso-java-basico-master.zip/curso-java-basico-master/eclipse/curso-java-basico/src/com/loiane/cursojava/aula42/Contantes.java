package com.loiane.cursojava.aula42;

public final class Contantes {

	public static final String URL_BLOG = "http://loiane.com";
	public static final String CURSO_COMPLETO = "http://loiane.training";
	
	//private String urlBlog;
}
