package com.loiane.cursojava.aula64;

public interface Texto {

	void imprimeTexto();
}
