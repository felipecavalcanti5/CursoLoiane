package com.loiane.cursojava.aulas85_100;

import org.apache.commons.lang3.StringUtils;

public class Aula100UsandoJars {

	public static void main(String[] args) {
		
		System.out.println(StringUtils.capitalize("loiane"));

	}

}
