Diretório com as listas de exercícios em formato pdf.
