package com.loiane.cursojava.aula11;

public class VariaveisChar {

	public static void main(String[] args) {
		
		//char o = 'o';
		//char i = 'i';
		
		char o = 111;
		char i = 105;
		char interrogacao = 0X00E1; // valor '?'
		
		System.out.println(""+o+i+interrogacao);

	}

}
